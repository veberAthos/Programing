# Control con excepciones multiples

"""try:
    n = input("Ingresa un numero: ")
    operacion = 5/n
except Exception as e:
    print("Ha ocurrido un error =>", type(e).__name__)"""

#print(type(e)) # muestra el nombre de la clase del error
# print(type(e).__name__)

# obtener el tipo de datos de algunas expresiones
print(type(1))
print(type(3.14))
print(type([]))
print(type(()))
print(type({}))

try:
    n = float(input("Ingrese un numero: "))
    operacion = 5/n
except TypeError:
    print("No se puede dividir el número entre una cadena")
except ValueError:
    print("Debes ingresar un valor que sea numerico")
except ZeroDivisionError:
    print("No se puede dividir por cero, ingrese otro numero")
except Exception as e:
    print("Ha ocurrido un error =>", type(e).__name__)