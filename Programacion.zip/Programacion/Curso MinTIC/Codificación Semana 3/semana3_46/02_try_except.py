# Manejo de excepciones

# Bloque try - except

"""try:
    n = float(input("Ingresa un número: "))
    m = 4
    print("{}/{}={}".format(n,m,n/m))
except:
    print("Ha ocurrido un error, debes ingresar un valor númerico")"""

"""while(True):
    try:
        n = float(input("Ingresa un número: "))
        m = 4
        print("{}/{}={}".format(n,m,n/m))
        break
    except:
        print("Ha ocurrido un error, debes ingresar un valor númerico")"""

# Bloque else
"""while(True):
    try:
        n = float(input("Ingresa un número: "))
        m = 4
        print("{}/{}={}".format(n,m,n/m))
    except:
        print("Ha ocurrido un error, debes ingresar un valor númerico")
    else:
        print("Todo ha funcionado correctamente")
        break"""

# Bloque finally
while(True):
    try:
        n = float(input("Ingresa un número: "))
        m = 4
        print("{}/{}={}".format(n,m,n/m))
    except:
        print("Ha ocurrido un error, debes ingresar un valor númerico")
    else:
        print("Todo ha funcionado correctamente")
        break
    finally:
        print("Fin de la iteración")