# Programa que declare una lista y la vaya llenando de números hasta que 
# introduzcamos un número negativo. Entonces se debe imprimir el vector o lista o array
# (sólo los elementos introducidos).

listaNumeros = []
try:
    numero = int(input("Ingrese un número a la lista: "))
except:
    print("Debes ingresar un valor númerico")

while numero >= 0:
    listaNumeros.append(numero)
    try:
        numero = int(input("Ingrese un número a la lista: "))
    except:
        print("Debes ingresar un valor númerico")

for numero in listaNumeros:
    print(numero," ",end="")