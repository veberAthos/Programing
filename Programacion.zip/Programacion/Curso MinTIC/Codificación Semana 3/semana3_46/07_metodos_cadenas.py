# METODOS EN LAS CADENAS

# upper() devuelve la cadena con todos su caracteres a mayuscula
cadena = "Hola mundo"
print(cadena.upper())

# lower() devuelve la cadena con todos sus caracteres a minuscula
cadena = "HOLA MUNDO"
print(cadena.lower())

# capitalize() devuelve la cadena con su primer caracter en mayuscula
cadena = "hola mundo"
print(cadena.capitalize())

# title() devuelve la cadena con el primer caracter de cada palabra en mayuscula
cadena = "hola mundo python"
print(cadena.title())

# count() devuelve una cuenta de las veces que aparece una subcadena en la cadena
cadena = "hola mundo mundo"
print(cadena.count('mundo'))

# find() devuelve el indice en el que aparece la subcadena (-1 si no aparece)
cadena = "Hola mundo"
print(cadena.find('mundo'))

# rfind() devuelve el indice en el que aparece la subacedena, empezando por el final
cadena = "Hola mundo mundo mundo"
print(cadena.rfind('m'))

# isdigit() devuelve true si la cadena es todo números false en caso de lo contrario
cadena = "100"
print(cadena.isdigit())

# isalnum() devuelve true si la cadena es todo numeros o caracteres alfabeticos
cadena = "ACB10034pro"
print(cadena.isalnum())

# isalpha() devuelve true si la cadena es todo caracteres alfabeticos
cadena = "ACBpro"
print(cadena.isalpha())

# islower() devuelve true si la cadena es todo minuscula
cadena = "hola mundo"
print(cadena.islower())

# isupper() devuelve true si la cadena es todo mayuscula
cadena = "HOLA MUNDO"
print(cadena.isupper())

# istitle() devuelve un true si la primera letra de cada palabra es mayuscula
cadena = "Hola Mundo"
print(cadena.istitle())

# isspace() devuelve true si la cadena es todo espacios en blanco
cadena = " "
print(cadena.isspace())

# startwith() devuelve true si la cadena empieza con una subcadena
cadena = "Hola mundo"
print(cadena.startswith("mundo"))

# endswith() devuelve si la cadena acaba con una subcadena
cadena = "Hola mundo"
print(cadena.endswith('mundo'))

# split() separa la cadena en subcadenas a partir de sus espacios en blanco o caracteres y devuelve una lista
cadena = "Hola mundo de python"
listaResultado = cadena.split()
print(listaResultado)
hola = listaResultado[0]
print(hola)

cadena = "Hola@mundo@de@python"
listaResultado = cadena.split('@')
print(listaResultado)

# join() une todos los caracteres de una cadena utilizando un caracter de union
caracter = "@"
print(caracter.join("Hola mundo"))

# strip() borra todos los espacios por delante y detras de una cadena y la devuelve
cadena = "   hola   "
print(cadena.strip())

cadena = "----hola----"
print(cadena.strip('-'))

# replace() reemplaza una subcadena de una cadena por otra y la devuelve
cadena = "Hola mundo python"
print(cadena.replace('o','0'))

cadena = "Hola mundo mundo mundo mundo mundo"
print(cadena.replace(' mundo', '', 4))

