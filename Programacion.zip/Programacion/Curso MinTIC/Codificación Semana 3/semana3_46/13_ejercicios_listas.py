# Crea un programa que pida un número al usuario un número de mes 
# (por ejemplo, el 4) y diga cuántos días tiene (por ejemplo, 30) 
# y el nombre del mes. Debes usar listas. Para simplificarlo vamos 
# a suponer que febrero tiene 28 días.

dias = [31,28,31,30,31,30,31,31,30,31,30,31]
meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]

while(True):
    numeroMes = int(input("Ingrese un mes en el rango de 1 - 12: "))
    if numeroMes >= 1 and numeroMes <= 12:
        break
    else:
        print("Error: mes incorrecto")

mostrarMes = meses[numeroMes-1]
diasMes = dias[numeroMes-1]

print(f"El mes de {mostrarMes}, tiene {diasMes} días")