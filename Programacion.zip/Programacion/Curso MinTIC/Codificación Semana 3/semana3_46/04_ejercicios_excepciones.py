# Localiza el error en el siguiente bloque de código. 
# Crea una excepción para evitar que el programa se bloquee y además explica 
# en un mensaje al usuario la causa y/o solución:

try:
    resultado = 10/0
except ZeroDivisionError:
    print("Error: No es posible dividir por cero, debes ingresar otro numero.")