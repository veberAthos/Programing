# Errores de sintaxis SintaxError
#print("Hola"

# Errores de nombre NameError
#pint("Hola")

# Errores semanticos IndexError
lista = []
# pop() permite extraer elementos de una lista 

# validacion realizada por el developer
cantidadItemLista = len(lista)
if cantidadItemLista > 0:
    lista.pop()
else:
    print("La lista se encuentra vacia.")

if cantidadItemLista != 0:
    lista.pop()
#**************************************

# TypeError voy una operacion aritmetica e ingresa cadena
"""n = input("Ingresa un número: ")
m = 4
print("{}/{}={}".format(n,m,n/m))"""

# ValueError que el usuario ingresa una cadena
n = float(input("Ingresa un número: "))
m = 4
print("{}/{}={}".format(n,m,n/m))