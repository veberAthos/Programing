# METODOS DE LAS LISTAS

# append() añadir un elemento o item al final de una lista
lista = [1,2,3,4,5]
lista.append(6)
print(lista)

# clear() vaciar todos los items de una lista
lista.clear()
print(lista)

# extend() une una lista con otra
l1 = [1,2,3]
l2 = [4,5,6]
l1.extend(l2)
print(l1)

# count() cuenta el numero de veces que aparece un elemento o item dentro una lista
listaCadena = ["Hola", "mundo", "mundo"]
print(listaCadena.count("mundo"))

# index() devuelve el indice en el que aparece un item (error si no aparece)
listaCadena = ["Hola", "mundo", "mundo"]
print(listaCadena.index("mundo"))

# insert() agrega un item a la lista en un indice especifico
lista2 = [1,2,3]
lista2.insert(0,0)
print(lista2)

# pop() extraer un elemento o item de la lista y lo borra
lista3 = [10,20,30,40,50]
print(lista3.pop())
print(lista3)

print(lista3.pop(0))
print(lista3)

# remove() borra el primer item de la lista cuyo valor concuerde con el que indicamos
lista4 = [20,30,30,30,40]
lista4.remove(30)
print(lista4)

# reverse() le da vuelta a la lista 
lista5 = [70,80,90,100]
lista5.reverse()
print(lista5)

# sort() ordena automaticamente los item de una lista por su valor de menor a mayor
#lista6 =[5,-10,35,0,-65,100]
lista6 =['z', 't', 'a', 'x']
lista6.sort()
print(lista6)