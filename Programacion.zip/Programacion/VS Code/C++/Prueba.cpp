#include <iostream>

using namespace std;

int main(){
    cout << "Hola, esto es una prueba\n";
}