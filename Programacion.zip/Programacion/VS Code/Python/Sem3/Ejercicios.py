# Localiza el error en el siguiente bloque de codigo.
# Cree una excepcion para evitar que el programa se bloquee y además explica
# en un mensaje al usuario la causa y/o solución:
"""
try:
    resultado = 10/0
except ZeroDivisionError:
    print("Error: No es posible dividir por cero, debes ingresar otro número")
"""

# Localiza el error en el sigte bloque de codigo.
# Cree una excepcion para evitar que el programa se bloquee y además explica
# en un mensaje al usuario la causa y/o solución:

#lista = [1,2,3,4,5]
#lista[10]
"""
lista = [1,2,3,4,5]

try:
    lista[10]
except IndexError:
    print("Error: el indice que quiere acceder está fuera del rango de la lista.")
"""
#***********************************************************************************

# Saber si una variable está vacía se usa. -None-