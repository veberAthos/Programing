# Control con excepciones multiples

"""try:
    n = input("Ingresa un número: ")
    operacion = 5/n

except Exception as e:
    print("Ha ocurrido un error => ", type (e).__name__)"""

# print(type(e)) muestra el nombre de la clase del error
# print(type(e)._name_)

print()

try:
    n = input("Ingresa un número: ")
    operacion = 5/n

except TypeError:
    print("No se puede dividir el número entre una cadena")
except Exception as e:
    print("Ha ocurrido un error => ", type (e).__name__)