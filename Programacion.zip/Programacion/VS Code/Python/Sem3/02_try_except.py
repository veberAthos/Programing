# Manejo de excepciones

# Bloque Try - Except
"""try:
    n = float(input("Ingrese un número: "))
    m = float(4)
    print("{}/{}={}".format(n,m,n/m))
except:
    print("Ha ocurrido un error, debes ingresar un valor numérico")"""

while (True):
    try:
        n = float(input("Ingrese un número: "))
        m = float(4)
        print("{}/{}={}".format(n,m,n/m))
    except:
        print("Ha ocurrido un error, debes ingresar un valor numérico")
    else:
        print("Todo ha funcionado correctamente")
        break
    finally:
        print("Muchas gracias por su colaboración")