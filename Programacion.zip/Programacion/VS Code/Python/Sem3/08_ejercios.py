# Realizar un programa que inicialice una lista con 10 valores aleatorios (del 1 al 10)
# y posteriormente muestre en pantalla cada elemento de la lista junto con su cuadrado
# y su cubo
"""
import random

listaNum = []

for i in range(10):
    listaNum.append(random.randint(1,10))

for j in listaNum:
    print(f"base {j},\tcuadrado {j**2},\tcubo {j**3}")

print(listaNum)
"""

# Crea una lista e inicializala con 5 cadenas de caracteres leidas por teclado.
# Copia los elementos de la lista en otra lista pero en orden inverso, y muestra
# sus elementos por la pantalla

lista1 = []
lista2 = []
for index in range(5):
    cadena = input("Ingrese una cadena: ")
    lista1.append(cadena)

lista2 = lista1

print(lista1)

lista2.reverse()

for cadena in range(len(lista2)):
    print(lista2[cadena])