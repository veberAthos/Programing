# islower() devuelve si la cadena es toda minuscula
cadena = "hola mundo"
print(cadena.islower())

# isupper() devuelve si la cadena es toda mayúscula
cadena = "HOLA MUNDO"
print(cadena.isupper())

# istitle() devuelve true se la primera letra de cada palabra es mayúscula
cadena = "Hola Mundo"
print(cadena.istitle())

# isspace() devuelve true si la cadena es todo espacios en blanco
cadena = " "
print(cadena.isspace())

# startswith() devuelve true si la cadena empieza con una subcadena
cadena = "Hola mundo"
print(cadena.startswith("Hola"))

# endswith() devuelve se la cadena acaba con una subcadena
cadena = "Hola mundo"
print(cadena.endswith("mundo"))

# split() separa la cadena por por un caracter dado (espacio por default) y forma una lista
cadena = "Hola mundo python"
listaResultado = cadena.split()
print(listaResultado)
hola = listaResultado[0]
print(hola)

cadena = "Hola@mundo@de@python"
listaResultado = cadena.split("@")

# join() une todos los caracteres de una cadena utilizando un caracter de unión
caracter = "@"
print(caracter.join("Hola mundo"))

# strip() borra los espacios por delante y detras de una cadena y la devuelve
cadena = "   hola   "
print(cadena.strip())

# replace() reemplaza una subcadena de una cadena por otra y la devuelve
cadena = "Hola mundo python"
print(cadena.replace("o","0"))

cadena = "Hola mundo mundo mundo mundo"
print(cadena.replace(" mundo", "", 4))