# Errores de sintaxis: syntaxError
# print("hola"

# Errores de Nombre:;NameError
#pint("hola")

# Errores semánticos: IndexError
# lista = []
# lista.pop()
#Traceback (most recent call last):
#  File "d:\Documentos\Trabajos Vic\Programacion\VS Code\Python\Sem3\Sem3_01_errores.py", line 10, in <module>
#    lista.pop()
#IndexError: pop from empty list

lista = []

cantidadItemLista = len(lista) # validacion realiazda por el developer

if cantidadItemLista > 0:
    lista.pop() #extrae los elementos de la lista (populate)
else:
    print("La lista está vacia.")

if cantidadItemLista != 0:
    lista.pop()

#******************************************************